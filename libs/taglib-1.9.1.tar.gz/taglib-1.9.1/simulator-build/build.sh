#!/bin/sh
cmake -DCMAKE_TOOLCHAIN_FILE=simulator.toolchain -DCMAKE_INSTALL_PREFIX=/Users/okosenkov/Projects/bb10 -DCMAKE_FIND_ROOT_PATH=/Users/okosenkov/Projects/bb10 -DCMAKE_BUILD_TYPE=Release -DENABLE_STATIC=ON -DCMAKE_VERBOSE_MAKEFILE=TRUE -G "Unix Makefiles" ..
